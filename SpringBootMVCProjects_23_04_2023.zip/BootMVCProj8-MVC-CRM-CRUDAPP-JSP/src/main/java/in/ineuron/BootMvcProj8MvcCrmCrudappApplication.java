package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcProj8MvcCrmCrudappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMvcProj8MvcCrmCrudappApplication.class, args);
	}

}
